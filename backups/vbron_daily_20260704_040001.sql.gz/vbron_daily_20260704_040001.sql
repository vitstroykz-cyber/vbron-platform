--
-- PostgreSQL database dump
--

\restrict mzqhM1MOgECxqM086aynNVWxpdec47V8KqAek2MDYot7J9jl5x6Z0O7cHOfxd49

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.settings DROP CONSTRAINT IF EXISTS settings_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.rooms DROP CONSTRAINT IF EXISTS rooms_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.reviews DROP CONSTRAINT IF EXISTS reviews_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.reviews DROP CONSTRAINT IF EXISTS reviews_booking_id_fkey;
ALTER TABLE IF EXISTS ONLY public.bookings DROP CONSTRAINT IF EXISTS bookings_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.bookings DROP CONSTRAINT IF EXISTS bookings_room_id_fkey;
DROP TRIGGER IF EXISTS update_tenants_updated_at ON public.tenants;
DROP TRIGGER IF EXISTS update_settings_updated_at ON public.settings;
DROP TRIGGER IF EXISTS update_rooms_updated_at ON public.rooms;
DROP TRIGGER IF EXISTS update_bookings_updated_at ON public.bookings;
DROP INDEX IF EXISTS public.idx_users_tenant;
DROP INDEX IF EXISTS public.idx_users_email;
DROP INDEX IF EXISTS public.idx_tenants_slug;
DROP INDEX IF EXISTS public.idx_tenants_active;
DROP INDEX IF EXISTS public.idx_settings_tenant;
DROP INDEX IF EXISTS public.idx_rooms_tenant;
DROP INDEX IF EXISTS public.idx_rooms_active;
DROP INDEX IF EXISTS public.idx_reviews_tenant;
DROP INDEX IF EXISTS public.idx_reviews_published;
DROP INDEX IF EXISTS public.idx_bookings_tenant;
DROP INDEX IF EXISTS public.idx_bookings_status;
DROP INDEX IF EXISTS public.idx_bookings_room_dates;
DROP INDEX IF EXISTS public.idx_bookings_created;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.tenants DROP CONSTRAINT IF EXISTS tenants_slug_key;
ALTER TABLE IF EXISTS ONLY public.tenants DROP CONSTRAINT IF EXISTS tenants_pkey;
ALTER TABLE IF EXISTS ONLY public.settings DROP CONSTRAINT IF EXISTS settings_tenant_id_key_key;
ALTER TABLE IF EXISTS ONLY public.settings DROP CONSTRAINT IF EXISTS settings_pkey;
ALTER TABLE IF EXISTS ONLY public.rooms DROP CONSTRAINT IF EXISTS rooms_pkey;
ALTER TABLE IF EXISTS ONLY public.reviews DROP CONSTRAINT IF EXISTS reviews_pkey;
ALTER TABLE IF EXISTS ONLY public.bookings DROP CONSTRAINT IF EXISTS bookings_pkey;
ALTER TABLE IF EXISTS public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.tenants ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.settings ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.rooms ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.reviews ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.bookings ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.users_id_seq;
DROP TABLE IF EXISTS public.users;
DROP SEQUENCE IF EXISTS public.tenants_id_seq;
DROP TABLE IF EXISTS public.tenants;
DROP SEQUENCE IF EXISTS public.settings_id_seq;
DROP TABLE IF EXISTS public.settings;
DROP SEQUENCE IF EXISTS public.rooms_id_seq;
DROP TABLE IF EXISTS public.rooms;
DROP SEQUENCE IF EXISTS public.reviews_id_seq;
DROP TABLE IF EXISTS public.reviews;
DROP SEQUENCE IF EXISTS public.bookings_id_seq;
DROP TABLE IF EXISTS public.bookings;
DROP FUNCTION IF EXISTS public.update_updated_at_column();
DROP EXTENSION IF EXISTS "uuid-ossp";
--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: vbron_user
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO vbron_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bookings; Type: TABLE; Schema: public; Owner: vbron_user
--

CREATE TABLE public.bookings (
    id integer NOT NULL,
    tenant_id integer NOT NULL,
    room_id integer NOT NULL,
    guest_name character varying(200) NOT NULL,
    guest_phone character varying(50) NOT NULL,
    guest_email character varying(200),
    check_in date NOT NULL,
    check_out date NOT NULL,
    guests_count integer DEFAULT 1,
    status character varying(20) DEFAULT 'new'::character varying,
    payment_status character varying(20) DEFAULT 'unpaid'::character varying,
    total_price numeric(10,2),
    prepayment numeric(10,2) DEFAULT 0,
    source character varying(30) DEFAULT 'site'::character varying,
    notes text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    CONSTRAINT check_dates CHECK ((check_out > check_in))
);


ALTER TABLE public.bookings OWNER TO vbron_user;

--
-- Name: bookings_id_seq; Type: SEQUENCE; Schema: public; Owner: vbron_user
--

CREATE SEQUENCE public.bookings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bookings_id_seq OWNER TO vbron_user;

--
-- Name: bookings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vbron_user
--

ALTER SEQUENCE public.bookings_id_seq OWNED BY public.bookings.id;


--
-- Name: reviews; Type: TABLE; Schema: public; Owner: vbron_user
--

CREATE TABLE public.reviews (
    id integer NOT NULL,
    tenant_id integer NOT NULL,
    booking_id integer,
    guest_name character varying(200),
    rating integer,
    text text,
    is_published boolean DEFAULT false,
    ai_sentiment character varying(20),
    needs_attention boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now(),
    CONSTRAINT reviews_rating_check CHECK (((rating >= 1) AND (rating <= 5)))
);


ALTER TABLE public.reviews OWNER TO vbron_user;

--
-- Name: reviews_id_seq; Type: SEQUENCE; Schema: public; Owner: vbron_user
--

CREATE SEQUENCE public.reviews_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.reviews_id_seq OWNER TO vbron_user;

--
-- Name: reviews_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vbron_user
--

ALTER SEQUENCE public.reviews_id_seq OWNED BY public.reviews.id;


--
-- Name: rooms; Type: TABLE; Schema: public; Owner: vbron_user
--

CREATE TABLE public.rooms (
    id integer NOT NULL,
    tenant_id integer NOT NULL,
    name character varying(200) NOT NULL,
    type character varying(50),
    capacity integer DEFAULT 2,
    price_per_day numeric(10,2) NOT NULL,
    description text,
    photos jsonb DEFAULT '[]'::jsonb,
    amenities jsonb DEFAULT '[]'::jsonb,
    display_order integer DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.rooms OWNER TO vbron_user;

--
-- Name: rooms_id_seq; Type: SEQUENCE; Schema: public; Owner: vbron_user
--

CREATE SEQUENCE public.rooms_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.rooms_id_seq OWNER TO vbron_user;

--
-- Name: rooms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vbron_user
--

ALTER SEQUENCE public.rooms_id_seq OWNED BY public.rooms.id;


--
-- Name: settings; Type: TABLE; Schema: public; Owner: vbron_user
--

CREATE TABLE public.settings (
    id integer NOT NULL,
    tenant_id integer NOT NULL,
    key character varying(100) NOT NULL,
    value text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.settings OWNER TO vbron_user;

--
-- Name: settings_id_seq; Type: SEQUENCE; Schema: public; Owner: vbron_user
--

CREATE SEQUENCE public.settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.settings_id_seq OWNER TO vbron_user;

--
-- Name: settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vbron_user
--

ALTER SEQUENCE public.settings_id_seq OWNED BY public.settings.id;


--
-- Name: tenants; Type: TABLE; Schema: public; Owner: vbron_user
--

CREATE TABLE public.tenants (
    id integer NOT NULL,
    slug character varying(50) NOT NULL,
    name character varying(200) NOT NULL,
    owner_name character varying(200),
    owner_phone character varying(50),
    owner_email character varying(200),
    plan character varying(20) DEFAULT 'start'::character varying,
    telegram_chat_id character varying(100),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.tenants OWNER TO vbron_user;

--
-- Name: tenants_id_seq; Type: SEQUENCE; Schema: public; Owner: vbron_user
--

CREATE SEQUENCE public.tenants_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tenants_id_seq OWNER TO vbron_user;

--
-- Name: tenants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vbron_user
--

ALTER SEQUENCE public.tenants_id_seq OWNED BY public.tenants.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: vbron_user
--

CREATE TABLE public.users (
    id integer NOT NULL,
    tenant_id integer NOT NULL,
    email character varying(200) NOT NULL,
    password_hash character varying(255) NOT NULL,
    full_name character varying(200),
    role character varying(20) DEFAULT 'admin'::character varying,
    is_active boolean DEFAULT true,
    last_login_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.users OWNER TO vbron_user;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: vbron_user
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO vbron_user;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vbron_user
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: bookings id; Type: DEFAULT; Schema: public; Owner: vbron_user
--

ALTER TABLE ONLY public.bookings ALTER COLUMN id SET DEFAULT nextval('public.bookings_id_seq'::regclass);


--
-- Name: reviews id; Type: DEFAULT; Schema: public; Owner: vbron_user
--

ALTER TABLE ONLY public.reviews ALTER COLUMN id SET DEFAULT nextval('public.reviews_id_seq'::regclass);


--
-- Name: rooms id; Type: DEFAULT; Schema: public; Owner: vbron_user
--

ALTER TABLE ONLY public.rooms ALTER COLUMN id SET DEFAULT nextval('public.rooms_id_seq'::regclass);


--
-- Name: settings id; Type: DEFAULT; Schema: public; Owner: vbron_user
--

ALTER TABLE ONLY public.settings ALTER COLUMN id SET DEFAULT nextval('public.settings_id_seq'::regclass);


--
-- Name: tenants id; Type: DEFAULT; Schema: public; Owner: vbron_user
--

ALTER TABLE ONLY public.tenants ALTER COLUMN id SET DEFAULT nextval('public.tenants_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: vbron_user
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: bookings; Type: TABLE DATA; Schema: public; Owner: vbron_user
--

COPY public.bookings (id, tenant_id, room_id, guest_name, guest_phone, guest_email, check_in, check_out, guests_count, status, payment_status, total_price, prepayment, source, notes, created_at, updated_at) FROM stdin;
3	1	3	Тест 3	+77001234569	\N	2026-10-05	2026-10-06	1	confirmed	unpaid	15000.00	0.00	site	\N	2026-06-27 22:56:27.167806	2026-06-27 23:24:58.640368
2	1	2	Тест 2	+77001234568	\N	2026-09-10	2026-09-12	1	confirmed	unpaid	70000.00	0.00	site	\N	2026-06-27 22:52:09.638966	2026-06-27 23:25:04.818837
1	1	1	Тест Тестов	+77001234567	\N	2026-08-15	2026-08-17	1	confirmed	unpaid	50000.00	0.00	site	\N	2026-06-27 22:46:09.794943	2026-06-27 23:25:07.06575
4	1	1	dsd	sdsd	\N	2026-06-03	2026-06-06	1	confirmed	unpaid	75000.00	0.00	manual	\N	2026-06-27 23:25:18.69078	2026-06-27 23:25:18.69078
5	1	2	vasya	9879679867986	\N	2026-06-08	2026-06-16	1	confirmed	unpaid	280000.00	0.00	site	\N	2026-06-27 23:36:11.568128	2026-06-27 23:36:38.962843
6	1	2	wrtyyy	5768764745745	\N	2026-06-01	2026-06-05	1	confirmed	unpaid	140000.00	0.00	site	\N	2026-06-27 23:37:12.688354	2026-06-28 21:50:14.562081
7	1	1	фывапро	57474745745745745	\N	2026-06-30	2026-07-02	1	confirmed	unpaid	50000.00	0.00	site	\N	2026-06-28 21:12:15.417674	2026-06-28 21:50:16.771677
8	1	2	Jdjdj	32626262635653	\N	2026-08-03	2026-08-14	1	cancelled	unpaid	385000.00	0.00	site	\N	2026-06-28 21:13:21.386428	2026-06-28 22:56:32.506775
9	1	1	аывапывпыв	6373575375375	\N	2026-07-15	2026-07-16	1	confirmed	unpaid	25000.00	0.00	site	\N	2026-06-28 23:20:53.833885	2026-07-02 22:06:30.217747
\.


--
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: vbron_user
--

COPY public.reviews (id, tenant_id, booking_id, guest_name, rating, text, is_published, ai_sentiment, needs_attention, created_at) FROM stdin;
\.


--
-- Data for Name: rooms; Type: TABLE DATA; Schema: public; Owner: vbron_user
--

COPY public.rooms (id, tenant_id, name, type, capacity, price_per_day, description, photos, amenities, display_order, is_active, created_at, updated_at) FROM stdin;
3	1	Финская сауна на воде	sauna	8	17500.00	Отдельностоящая сауна на пирсе с прямым выходом к воде. Вместимость до 8 человек. Финская парная на дровах, комната отдыха с кожаными диванами, две душевые, бассейн с подогревом рядом, чайная зона с самоваром, панорамный вид на водохранилище. В стоимость входят веники и полотенца. Аренда почасовая — от 3 часов.	["https://images.unsplash.com/photo-1554310603-d39d43033735?w=1200", "https://images.unsplash.com/photo-1571902943202-507ec2618e8f?w=1200"]	["Бассейн с подогревом", "Парная на дровах", "Зона отдыха", "Чайная", "Веники"]	0	t	2026-06-27 21:58:30.554213	2026-07-03 20:19:04.857897
1	1	Домик у воды «Балауса»	cottage	6	40000.00	Уютный 2-комнатный домик 45 м² в 20 метрах от берега Капчагайского водохранилища. Панорамные окна с видом на воду, терраса с плетёной мебелью, гостиная с камином, спальня с двуспальной кроватью, отдельная ванная комната с душем, мини-кухня с холодильником и посудой. Идеально для двоих на выходные.	["https://images.unsplash.com/photo-1587061949409-02df41d5e562?w=1200", "https://images.unsplash.com/photo-1568605114967-8130f3a36994?w=1200", "https://images.unsplash.com/photo-1540541338287-41700207dee6?w=1200"]	["Wi-Fi", "Камин", "Терраса", "Парковка", "Постельное бельё"]	0	t	2026-06-27 21:58:30.554213	2026-07-04 00:24:19.756606
2	1	Семейный домик «Алтын»	cottage	6	37500.00	Просторный 3-комнатный дом 90 м² для большой компании или семьи до 6 человек. Первая линия от воды, вид на закат над Капчагаем. Две спальни, большая гостиная с камином, кухня-столовая с обеденным столом на 8 персон, баня на дровах с предбанником, крытая мангальная зона с уличной мебелью, парковка на 3 авто.	["https://images.unsplash.com/photo-1449158743715-0a90ebb6d2d8?w=1200", "https://images.unsplash.com/photo-1505873242700-f289a29e1e0f?w=1200", "https://images.unsplash.com/photo-1582268611958-ebfd161ef9cf?w=1200"]	["Wi-Fi", "Баня на дровах", "Мангал", "Камин", "Парковка для 3 авто", "Детская площадка"]	0	t	2026-06-27 21:58:30.554213	2026-07-03 20:19:03.111863
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: vbron_user
--

COPY public.settings (id, tenant_id, key, value, created_at, updated_at) FROM stdin;
1	1	lat	43.8720	2026-07-02 21:04:18.835292	2026-07-02 21:04:18.835292
2	1	lng	77.0687	2026-07-02 21:04:18.835292	2026-07-02 21:04:18.835292
3	1	address	Капчагайское водохранилище, южный берег, 55 км от Алматы	2026-07-02 21:04:18.835292	2026-07-02 21:04:18.835292
4	1	map_2gis_url	https://2gis.kz/almaty/geo/70000001071907017/77.0687%2C43.8720?m=77.0687%2C43.8720%2F17	2026-07-02 21:04:18.835292	2026-07-02 21:04:18.835292
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: vbron_user
--

COPY public.tenants (id, slug, name, owner_name, owner_phone, owner_email, plan, telegram_chat_id, is_active, created_at, updated_at) FROM stdin;
1	demo	База отдыха «Айсу» — Капчагай	Виталий (тест)	+77001234567	\N	premium	1919635803	t	2026-06-27 21:58:30.464805	2026-07-02 20:38:33.235216
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: vbron_user
--

COPY public.users (id, tenant_id, email, password_hash, full_name, role, is_active, last_login_at, created_at) FROM stdin;
1	1	vitstroykz@gmail.com	b0	Виталий	owner	t	2026-07-03 20:00:44.339885	2026-06-27 23:16:51.453116
\.


--
-- Name: bookings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vbron_user
--

SELECT pg_catalog.setval('public.bookings_id_seq', 10, true);


--
-- Name: reviews_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vbron_user
--

SELECT pg_catalog.setval('public.reviews_id_seq', 1, false);


--
-- Name: rooms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vbron_user
--

SELECT pg_catalog.setval('public.rooms_id_seq', 3, true);


--
-- Name: settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vbron_user
--

SELECT pg_catalog.setval('public.settings_id_seq', 4, true);


--
-- Name: tenants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vbron_user
--

SELECT pg_catalog.setval('public.tenants_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vbron_user
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: bookings bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: vbron_user
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_pkey PRIMARY KEY (id);


--
-- Name: reviews reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: vbron_user
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_pkey PRIMARY KEY (id);


--
-- Name: rooms rooms_pkey; Type: CONSTRAINT; Schema: public; Owner: vbron_user
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: vbron_user
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- Name: settings settings_tenant_id_key_key; Type: CONSTRAINT; Schema: public; Owner: vbron_user
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_tenant_id_key_key UNIQUE (tenant_id, key);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: vbron_user
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_slug_key; Type: CONSTRAINT; Schema: public; Owner: vbron_user
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_slug_key UNIQUE (slug);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: vbron_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: vbron_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_bookings_created; Type: INDEX; Schema: public; Owner: vbron_user
--

CREATE INDEX idx_bookings_created ON public.bookings USING btree (created_at DESC);


--
-- Name: idx_bookings_room_dates; Type: INDEX; Schema: public; Owner: vbron_user
--

CREATE INDEX idx_bookings_room_dates ON public.bookings USING btree (room_id, check_in, check_out);


--
-- Name: idx_bookings_status; Type: INDEX; Schema: public; Owner: vbron_user
--

CREATE INDEX idx_bookings_status ON public.bookings USING btree (tenant_id, status);


--
-- Name: idx_bookings_tenant; Type: INDEX; Schema: public; Owner: vbron_user
--

CREATE INDEX idx_bookings_tenant ON public.bookings USING btree (tenant_id);


--
-- Name: idx_reviews_published; Type: INDEX; Schema: public; Owner: vbron_user
--

CREATE INDEX idx_reviews_published ON public.reviews USING btree (tenant_id, is_published);


--
-- Name: idx_reviews_tenant; Type: INDEX; Schema: public; Owner: vbron_user
--

CREATE INDEX idx_reviews_tenant ON public.reviews USING btree (tenant_id);


--
-- Name: idx_rooms_active; Type: INDEX; Schema: public; Owner: vbron_user
--

CREATE INDEX idx_rooms_active ON public.rooms USING btree (tenant_id, is_active);


--
-- Name: idx_rooms_tenant; Type: INDEX; Schema: public; Owner: vbron_user
--

CREATE INDEX idx_rooms_tenant ON public.rooms USING btree (tenant_id);


--
-- Name: idx_settings_tenant; Type: INDEX; Schema: public; Owner: vbron_user
--

CREATE INDEX idx_settings_tenant ON public.settings USING btree (tenant_id);


--
-- Name: idx_tenants_active; Type: INDEX; Schema: public; Owner: vbron_user
--

CREATE INDEX idx_tenants_active ON public.tenants USING btree (is_active);


--
-- Name: idx_tenants_slug; Type: INDEX; Schema: public; Owner: vbron_user
--

CREATE INDEX idx_tenants_slug ON public.tenants USING btree (slug);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: vbron_user
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_tenant; Type: INDEX; Schema: public; Owner: vbron_user
--

CREATE INDEX idx_users_tenant ON public.users USING btree (tenant_id);


--
-- Name: bookings update_bookings_updated_at; Type: TRIGGER; Schema: public; Owner: vbron_user
--

CREATE TRIGGER update_bookings_updated_at BEFORE UPDATE ON public.bookings FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: rooms update_rooms_updated_at; Type: TRIGGER; Schema: public; Owner: vbron_user
--

CREATE TRIGGER update_rooms_updated_at BEFORE UPDATE ON public.rooms FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: settings update_settings_updated_at; Type: TRIGGER; Schema: public; Owner: vbron_user
--

CREATE TRIGGER update_settings_updated_at BEFORE UPDATE ON public.settings FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: tenants update_tenants_updated_at; Type: TRIGGER; Schema: public; Owner: vbron_user
--

CREATE TRIGGER update_tenants_updated_at BEFORE UPDATE ON public.tenants FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: bookings bookings_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vbron_user
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.rooms(id) ON DELETE RESTRICT;


--
-- Name: bookings bookings_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vbron_user
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: reviews reviews_booking_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vbron_user
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_booking_id_fkey FOREIGN KEY (booking_id) REFERENCES public.bookings(id) ON DELETE SET NULL;


--
-- Name: reviews reviews_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vbron_user
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: rooms rooms_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vbron_user
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: settings settings_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vbron_user
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: users users_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vbron_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict mzqhM1MOgECxqM086aynNVWxpdec47V8KqAek2MDYot7J9jl5x6Z0O7cHOfxd49

